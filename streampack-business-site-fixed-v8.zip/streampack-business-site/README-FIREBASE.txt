MurtResell StreamPack + Business Tracker

Deploy this extracted folder to Netlify.

URLs:
/ = StreamPack
/business/ = Drop Ledger Business Tracker with Firebase cloud sync

Business Tracker cloud sync:
- Uses Firebase project murtresell313
- Sign in or create account on the Drop Ledger Cloud screen
- Data syncs through Firestore under users/{uid}/apps/dropledger

Important:
- Before replacing your live site, keep your existing backup JSON.
- Firebase Firestore is currently in test mode; after confirming the app works, update rules to only allow signed-in users to read/write their own data.

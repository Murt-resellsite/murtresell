FIX NOTES — Past shows disappearing after Resume
===================================================

WHAT WAS CAUSING IT
StreamPack was storing ALL of your past shows as one big list inside a
single shared cloud document. Every time you saved anything (including
hitting "Resume" on a show), the app re-uploaded that ENTIRE list and
overwrote whatever was in the cloud.

If your browser's copy of that list was even slightly out of date when
you hit Resume (e.g. right after loading the page, or if you had it
open in two tabs/two versions of the site), it would overwrite the
cloud's newer, more complete list with your older one — silently
deleting the shows that only existed in the newer version.

THE FIX
Each show is now saved as its own separate entry in the cloud, instead
of all shows being crammed into one shared list. Saving one show (or
resuming one) can no longer overwrite or delete any other show — there
is nothing left to "overwrite by accident." I also added a real
Recover From Backup screen (open Past Shows → 🛟 Recover From Backup)
that lists the automatic local snapshots this device already keeps, so
if something like this ever happens again, you can fix it yourself in
two clicks instead of losing the shows for good.

RECOVERING THE 3-4 SHOWS YOU JUST LOST
This code fix prevents it from happening again, but it can't bring back
shows that are already gone from the cloud. Before doing anything else:

1. Open your LIVE site (the one you were actually using) in the same
   browser you were using when it happened — don't clear your browser
   data or history.
2. Go to Past Shows → 🛟 Recover From Backup.
3. Look for a snapshot with a higher show count than what you have now
   (they're listed newest first, with a "+X more than now" label).
4. Hit "Restore This Snapshot" on the one right before the shows went
   missing. This also pushes them back to the cloud automatically.

If nothing in that list has your missing shows, they were likely lost
before this update was deployed and the automatic snapshots have since
rotated out. In that case they can't be recovered from the code alone —
sorry, I want to be straight with you about that rather than promise
something I can't deliver.
